
runfile('/Users/philippetapon/Google Drive/python_backup/Advanced efforts.py', wdir='/Users/philippetapon/Google Drive/python_backup')
import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to DD if in fact it's a depressive disorder: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


runfile('/Users/philippetapon/Google Drive/python_backup/Advanced efforts.py', wdir='/Users/philippetapon/Google Drive/python_backup')
import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class


import csv
with open('icd10codes.csv') as csvfile:
    diagnosis_reader = csv.reader(csvfile)


# We create a list of all the diagnosis classes.     

#	AD 	Addictive Disorders 
#	BD 	Bipolar Disorders 
#	DD 	Depressive Disorder 
#	DI 	Dissociative disorders 
#	ED 	Eating Disorders 
#	ID 	Impulse Disorders 
#	MA 	Malingering 
#	NC 	NeuroCognitive 
#	ND 	Neurodevelopmental Disorders 
#	OD 	Obsessive Disorder 
#	OT 	Other 
#	PD 	Personality Disorders 
#	SS 	Schizophrenia Spectrum 
#	TD 	Trauma Disorders 
#	XD 	anXiety Disorder 
    
    list_of_diagnosis_classes = ["AD", "BD", "DD", "DI", "ED", "ID",                                  "MA", "NC", "ND", "OD", "OT", "PD", "SS", "TD", "XD"]

# Get the length of the list of diagnosis classes, that we will need for the loop     
    length_of_dx_class = len(list_of_diagnosis_classes)

# Here starts the loop, as a for statement.  It goes through each row in the diagnosis reader, 
# so that the first column, the icd-10 code, gets put into row[0], and the disease class (what kind of disease
# it is, SS, DD, AD, etc.) gets put into row[2]. # We set the counter to 0.  We set the list of list of diagnoses to 15 blank lists.  15 matches
# the number of diagnosis classes; both are hard-coded.  
    
    list_of_list_of_dx = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
    
    for row in diagnosis_reader:
        icd10code = row[0]
        disease_class = row[2]  
        
        counter = 0


# A while loop starts.  While the counter is less than the number of diagnosis classes we have, 
# we want to create a list of all the diagnoses that are classified by a class held in common, such as, 
# for example, all the Schizophrenia Spectrum diseases, F20.9, F29, etc.  So that SS would be a list
# of several diagnosis all held in a list.          
        
        while counter < length_of_dx_class:
            dx_class = list_of_diagnosis_classes[counter]
            if disease_class == dx_class:
                list_of_list_of_dx[counter].append(icd10code)
            
            counter += 1        


dx_class_disease = []

# Now we import the patient list into a reader called patient_reader.  
# We create a variable called SS_patients and initialize it with a blank
# Then with a looping command, that includes an if statement that tests
# whether or not a patient's ICD-10 code is included in the list of schizophrenia-spectrum
# disorders 


import csv
with open('unified59dx.csv') as csvfile:
    patient_reader = csv.reader(csvfile)
    for row in patient_reader:
        MRN = row[0]  
        pt_icd10 = row[1]  


# Next we use the .split function to break the string pt_icd10 into a list, and put that list into split_pt_icd10
        
        split_pt_icd10 = pt_icd10.split()

# Then we get the list length, that we will need to number the iterations (the while loop)    
        
        list_length = len(split_pt_icd10)

# We set the disease_class (the kind of disease they have, be it SS, DD, etc.) to a blank
        
        disease_class = []


# We start the while loop.  First we set the counter to 0.  Then while the counter is less than the
# number of diagnoses (the list length) we test to see if the diagnosis is in the list of diseases we're looking
# at.  If it is, we set the disease_class to that sort of disease.  Then we add one to the counter.  
        
        counter = 0
        while counter < list_length:

# The list of diagnoses, where there are more than one, includes an unwanted comma, 
# that will not match to the list of special diagnoses.  
# The following strips the comma where it exists.  (A more elegant solution would be to implement
# this only when the list_length is over 1, because lists containing but one item have no commas!)  
            
            if split_pt_icd10[counter][-1] == ",":
                split_pt_icd10[counter] = split_pt_icd10[counter][:-1]

# Here is where we set the disease_class to each of the two-letter codes specified in the list at the beginning of the program: 
            inner_counter = 0
            while inner_counter < length_of_dx_class:
                if split_pt_icd10[counter] in list_of_list_of_dx[inner_counter]:
                    disease_class.append(list_of_diagnosis_classes[inner_counter])
                inner_counter += 1
            counter += 1    

# We would like to remove duplicates from the list; we do this by making it a set and then back into a list        
        disease_class = list(set(disease_class))
# We clean up the brackets and the quotation marks to make a presentable string separated by commas
        stringy_disease_class = ','.join(disease_class)
        print stringy_disease_class

